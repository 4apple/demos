export JAVA_HOME=/usr/lib/jvm/java-1.7.0-openjdk-amd64
export ANDROIDM_SDK=/local/sourcecode3/EspAppTools/gradle-sdk/EspAppTools/gradle-sdk
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$ANDROIDM_SDK:$PATH

